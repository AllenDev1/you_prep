import React from "react";
import NavBar from "../components/navbar";
const Review = () => {
  return (
    <>
      <NavBar />
      <h1>Hello </h1>
    </>
  );
};

export default Review;
