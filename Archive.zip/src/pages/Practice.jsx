import React from "react";
import NavBar from "../components/navbar";
const Practice = () => {
  return (
    <>
      <NavBar />
      <h1>I am Practice page!</h1>
    </>
  );
};

export default Practice;
