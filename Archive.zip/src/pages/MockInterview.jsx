import React from "react";

const MockInterview = () => {
  return (
    <>
      <h1>MockInterview</h1>
    </>
  );
};

export default MockInterview;
